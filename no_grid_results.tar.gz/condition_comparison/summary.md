# Explicit-belief versus no-grid layer comparison

- Explicit run: `/workspace/luoyuzhang/grid-world/runs/qwen25_7b_diverse5x5_1000_explicit_all_layers`
- No-grid run: `/workspace/luoyuzhang/grid-world/runs/qwen25_7b_no_grid_diverse5x5_1000`
- Common positions: prompt_last, pre_action_token
- Task groups: cells, planning, true_cells, true_cells_unobserved

The prompt-last comparison is the cleanest map-representation comparison because it occurs before either condition generates a response.

The pre-action comparison is useful for action selection, but in the explicit condition the model may already have generated its belief grid before the action field.

## Files

- `condition_layer_summary.csv`
- `cells_pre_action_token_condition_macro_f1.png`
- `cells_pre_action_token_condition_delta.png`
- `cells_prompt_last_condition_macro_f1.png`
- `cells_prompt_last_condition_delta.png`
- `planning_pre_action_token_condition_macro_f1.png`
- `planning_pre_action_token_condition_delta.png`
- `planning_prompt_last_condition_macro_f1.png`
- `planning_prompt_last_condition_delta.png`
- `true_cells_pre_action_token_condition_macro_f1.png`
- `true_cells_pre_action_token_condition_delta.png`
- `true_cells_prompt_last_condition_macro_f1.png`
- `true_cells_prompt_last_condition_delta.png`
- `true_cells_unobserved_pre_action_token_condition_macro_f1.png`
- `true_cells_unobserved_pre_action_token_condition_delta.png`
- `true_cells_unobserved_prompt_last_condition_macro_f1.png`
- `true_cells_unobserved_prompt_last_condition_delta.png`
