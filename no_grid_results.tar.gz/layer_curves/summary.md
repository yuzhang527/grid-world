# Layer-wise probe report

- Condition: **No explicit grid**
- Run: `/workspace/luoyuzhang/grid-world/runs/qwen25_7b_no_grid_diverse5x5_1000`
- Layer 0 is the embedding output.
- The final hidden-state index is the final normalized representation.
- Each group curve averages the same fixed set of tasks at every layer.
- No best-layer selection is used to construct the curves.

## Peak layer by task group and position

| task_group            | position         |   peak_layer |   peak_mean_macro_f1 |   peak_delta_over_majority |   tasks |
|:----------------------|:-----------------|-------------:|---------------------:|---------------------------:|--------:|
| cells                 | mean_history     |           23 |                0.746 |                      0.495 |      25 |
| cells                 | pre_action_token |           22 |                0.727 |                      0.477 |      25 |
| cells                 | prompt_last      |           19 |                0.692 |                      0.442 |      25 |
| memory                | mean_history     |           26 |                0.902 |                      0.516 |      25 |
| memory                | pre_action_token |           22 |                0.914 |                      0.528 |      25 |
| memory                | prompt_last      |           19 |                0.882 |                      0.496 |      25 |
| planning              | mean_history     |           20 |                0.825 |                      0.432 |       9 |
| planning              | pre_action_token |           22 |                0.851 |                      0.458 |       9 |
| planning              | prompt_last      |           22 |                0.838 |                      0.445 |       9 |
| true_cells            | mean_history     |           18 |                0.533 |                      0.088 |      25 |
| true_cells            | pre_action_token |           22 |                0.563 |                      0.118 |      25 |
| true_cells            | prompt_last      |           20 |                0.547 |                      0.101 |      25 |
| true_cells_unobserved | mean_history     |           20 |                0.472 |                      0.026 |      25 |
| true_cells_unobserved | pre_action_token |           22 |                0.500 |                      0.054 |      25 |
| true_cells_unobserved | prompt_last      |           21 |                0.488 |                      0.042 |      25 |

## Output files

- `layer_summary.csv`: group-level layer curves.
- `task_layer_curves.csv`: every task at every layer.
- `peak_layers.csv`: exploratory peak locations.
- `cells_macro_f1_by_layer.png`
- `cells_delta_by_layer.png`
- `memory_macro_f1_by_layer.png`
- `memory_delta_by_layer.png`
- `planning_macro_f1_by_layer.png`
- `planning_delta_by_layer.png`
- `true_cells_macro_f1_by_layer.png`
- `true_cells_delta_by_layer.png`
- `true_cells_unobserved_macro_f1_by_layer.png`
- `true_cells_unobserved_delta_by_layer.png`
- `planning_tasks_pre_action_token_by_layer.png`
